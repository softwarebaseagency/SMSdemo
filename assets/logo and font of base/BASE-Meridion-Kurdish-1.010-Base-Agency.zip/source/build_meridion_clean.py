"""BASE Meridion Kurdish - clean family rebuild (v1.003).

This rebuild starts from the already-correct Regular master (whose Kurdish
letters are imported "same same" from letter fixing.pdf) and:

  1. Regenerates Medium / SemiBold / Bold with a clean stroke-outset weight
     (skia-pathops), replacing the previous faux-bold that produced lumpy,
     self-intersecting, ~9x-bloated outlines.
  2. Fixes the family naming so the typographic family is exactly
     "BASE Meridion Kurdish" and the weight names are sub-styles, with a valid
     RIBBI split and no leftover 'Base-Kurdish' WWS name.

Only stdlib + fontTools + skia-pathops + PyMuPDF + uharfbuzz + Pillow required.
"""
from __future__ import annotations

import hashlib
import json
import zipfile
from dataclasses import dataclass
from pathlib import Path

import pathops
import uharfbuzz as hb
from fontTools.pens.cu2quPen import Cu2QuPen
from fontTools.pens.recordingPen import RecordingPen
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.ttLib import TTFont

ROOT = Path(r"C:\Users\Designer\Documents\custom font")
SRC_FONTS = ROOT / "extracted" / "fonts"
REGULAR_SRC = SRC_FONTS / "BASEMeridionKurdish-Regular.ttf"

FAMILY = "BASE Meridion Kurdish"
FILE_FAMILY = "BASEMeridionKurdish"
PACKAGE_STEM = "BASE-Meridion-Kurdish"
VERSION = "1.010"
# Smooth mode: skip the geometric PDF joined-form transplants and keep the base
# font's smooth/flowing connected shapes (user pivoted to the smooth reference).
SMOOTH = True

DIST = ROOT / f"{PACKAGE_STEM}-{VERSION}"
FONTS = DIST / "fonts"
DOCS = DIST / "documentation"
SOURCE = DIST / "source"
SPECIMEN = DIST / "specimen"


@dataclass(frozen=True)
class Style:
    label: str          # typographic subfamily (ID17)
    weight: int         # usWeightClass
    dilate: float       # stroke-outset radius in font units (0 = keep master)

    @property
    def stem(self) -> str:
        return f"{FILE_FAMILY}-{self.label}"

    @property
    def full(self) -> str:
        return f"{FAMILY} {self.label}"


STYLES = [
    Style("Regular", 400, 0.0),
    Style("Medium", 500, 14.0),
    Style("SemiBold", 600, 26.0),
    Style("Bold", 700, 40.0),
]


# --------------------------------------------------------------------------- #
# Clean weight generation
# --------------------------------------------------------------------------- #
def dilate_glyph(glyphset, gname, r):
    """Grow a glyph outward by r units using a centered stroke unioned with the
    fill. Produces a clean, self-intersection-free heavier outline."""
    fill = pathops.Path()
    glyphset[gname].draw(fill.getPen(glyphSet=glyphset))
    fill.simplify()

    stroked = pathops.Path()
    glyphset[gname].draw(stroked.getPen(glyphSet=glyphset))
    stroked.stroke(2 * r, pathops.LineCap.ROUND_CAP, pathops.LineJoin.ROUND_JOIN, 4.0)
    stroked.convertConicsToQuads(0.2)
    fill.convertConicsToQuads(0.2)

    result = pathops.op(fill, stroked, pathops.PathOp.UNION, fix_winding=True)
    result.simplify(fix_winding=True)

    ttpen = TTGlyphPen(glyphSet=None)
    result.draw(Cu2QuPen(ttpen, max_err=1.0, reverse_direction=True))
    return ttpen.glyph()


# --------------------------------------------------------------------------- #
# Round heh family (match the PDF isolated heh style in joined forms)
# --------------------------------------------------------------------------- #
# The base font's connected heh forms are a traditional naskh knot (uniFEEC) that
# clashes with the clean round isolated heh from the PDF. Rebuild the joined heh
# forms as the PDF round loop + baseline connectors so words match the design.
# Connection band measured from the base medial glyphs: y in [0, 150].
_CONN_Y0, _CONN_Y1 = 0, 150

_HEH_GROUPS = {
    "uni0647": {"init": "uniFEEB", "medi": "uniFEEC", "fina": "uniFEEA"},   # heh
    "uni06BE": {"init": "uniFBAC", "medi": "uniFBAD", "fina": "uniFBAB"},   # heh doachashmee
}
# ae (Kurdish 'e') final form glyph — non-joining left, connects on the right.
_AE_ISO, _AE_FINA = "uni06D5", "glyph00572"


def _loop_path(glyf, glyphset, iso_name, target_h, cx, y_bottom):
    gi = glyf[iso_name]
    gi.recalcBounds(glyf)
    h = gi.yMax - gi.yMin
    w = gi.xMax - gi.xMin
    s = target_h / h
    lw = w * s
    lx = cx - lw / 2
    rec = RecordingPen()
    glyphset[iso_name].draw(rec)
    path = pathops.Path()
    pen = path.getPen(glyphSet=glyphset)

    def tf(x, y):
        return ((x - gi.xMin) * s + lx, (y - gi.yMin) * s + y_bottom)

    class _T:
        def moveTo(self, p): pen.moveTo(tf(*p))
        def lineTo(self, p): pen.lineTo(tf(*p))
        def qCurveTo(self, *pts): pen.qCurveTo(*[tf(*q) if q else None for q in pts])
        def curveTo(self, *pts): pen.curveTo(*[tf(*q) for q in pts])
        def closePath(self): pen.closePath()
        def endPath(self):
            try:
                pen.endPath()
            except Exception:
                pass

    rec.replay(_T())
    path.simplify()
    return path, lw


def _bar(x0, x1):
    p = pathops.Path()
    pen = p.getPen(glyphSet=None)
    pen.moveTo((x0, _CONN_Y0)); pen.lineTo((x1, _CONN_Y0))
    pen.lineTo((x1, _CONN_Y1)); pen.lineTo((x0, _CONN_Y1)); pen.closePath()
    return p


def _build_connected(glyf, glyphset, iso_name, kind, advance, target_h=650):
    cx = advance / 2
    loop, lw = _loop_path(glyf, glyphset, iso_name, target_h, cx, 0)
    res = loop
    if kind in ("medi", "init"):    # exit to the next letter -> LEFT edge
        res = pathops.op(res, _bar(-35, cx + lw * 0.15), pathops.PathOp.UNION, fix_winding=True)
    if kind in ("medi", "fina"):    # entry from previous letter -> RIGHT edge
        res = pathops.op(res, _bar(cx - lw * 0.15, advance + 35), pathops.PathOp.UNION, fix_winding=True)
    res.simplify(fix_winding=True)
    tt = TTGlyphPen(None)
    res.draw(Cu2QuPen(tt, max_err=1.0, reverse_direction=True))
    g = tt.glyph()
    g.recalcBounds(glyf)
    return g


def fix_heh_forms(font: TTFont) -> int:
    glyf = font["glyf"]
    hmtx = font["hmtx"]
    glyphset = font.getGlyphSet()
    count = 0
    for iso, forms in _HEH_GROUPS.items():
        if iso not in glyf:
            continue
        for kind, gn in forms.items():
            if gn in glyf:
                adv = hmtx.metrics[gn][0]
                glyf[gn] = _build_connected(glyf, glyphset, iso, kind, adv)
                hmtx.metrics[gn] = (adv, glyf[gn].xMin)
                count += 1
    if _AE_FINA in glyf and _AE_ISO in glyf:
        adv = hmtx.metrics[_AE_FINA][0]
        glyf[_AE_FINA] = _build_connected(glyf, glyphset, _AE_ISO, "fina", adv)
        hmtx.metrics[_AE_FINA] = (adv, glyf[_AE_FINA].xMin)
        count += 1
    return count


# --------------------------------------------------------------------------- #
# Feh/qaf-style loop-head transplant: put the PDF isolated head into the joined
# forms so the body curves match the isolated design (not the base font).
# --------------------------------------------------------------------------- #
def _iso_pathops(glyphset, gn):
    p = pathops.Path()
    glyphset[gn].draw(p.getPen(glyphSet=glyphset))
    p.simplify()
    return p


def _rect(x0, y0, x1, y1):
    p = pathops.Path()
    pen = p.getPen(glyphSet=None)
    pen.moveTo((x0, y0)); pen.lineTo((x1, y0)); pen.lineTo((x1, y1)); pen.lineTo((x0, y1)); pen.closePath()
    return p


class _Trans:
    def __init__(self, pen, dx, dy):
        self.pen, self.dx, self.dy = pen, dx, dy
    def moveTo(self, p): self.pen.moveTo((p[0] + self.dx, p[1] + self.dy))
    def lineTo(self, p): self.pen.lineTo((p[0] + self.dx, p[1] + self.dy))
    def qCurveTo(self, *pts): self.pen.qCurveTo(*[(q[0] + self.dx, q[1] + self.dy) if q else None for q in pts])
    def curveTo(self, *pts): self.pen.curveTo(*[(q[0] + self.dx, q[1] + self.dy) for q in pts])
    def closePath(self): self.pen.closePath()
    def endPath(self):
        try:
            self.pen.endPath()
        except Exception:
            pass


def _translate(path, dx, dy):
    out = pathops.Path()
    path.draw(_Trans(out.getPen(glyphSet=None), dx, dy))
    return out


def _to_glyph(glyf, path):
    tt = TTGlyphPen(None)
    path.draw(Cu2QuPen(tt, max_err=1.0, reverse_direction=True))
    g = tt.glyph()
    g.recalcBounds(glyf)
    return g


def fix_feh_forms(font: TTFont) -> int:
    """Feh (ف). init/medi: transplant the PDF isolated head loop + connectors.
    fina: keep the exact isolated glyph (tail + head + dot) and add a right
    connector, so final feh matches the isolated design exactly."""
    glyf = font["glyf"]
    hmtx = font["hmtx"]
    glyphset = font.getGlyphSet()
    cmap = font.getBestCmap()
    if 0x0641 not in cmap:
        return 0
    feh = cmap[0x0641]
    iso = _iso_pathops(glyphset, feh)
    head = pathops.op(iso, _rect(1150, -60, 1980, 1260), pathops.PathOp.INTERSECTION, fix_winding=True)
    head.simplify(fix_winding=True)
    hb = head.bounds
    count = 0

    def init_medi(kind, adv):
        dx = (adv - 40) - hb[2]
        h = _translate(head, dx, 0)
        hx0, hx1 = hb[0] + dx, hb[2] + dx
        res = h
        if kind in ("init", "medi"):
            res = pathops.op(res, _rect(-35, 0, hx0 + 120, 150), pathops.PathOp.UNION, fix_winding=True)
        if kind == "medi":
            res = pathops.op(res, _rect(hx1 - 120, 0, adv + 35, 150), pathops.PathOp.UNION, fix_winding=True)
        res.simplify(fix_winding=True)
        return _to_glyph(glyf, res)

    for kind, gn in [("init", "uniFED3"), ("medi", "uniFED4")]:
        if gn in glyf:
            adv = hmtx.metrics[gn][0]
            glyf[gn] = init_medi(kind, adv)
            hmtx.metrics[gn] = (adv, glyf[gn].xMin)
            count += 1
    # final = isolated feh + right connector (exact isolated body)
    gn = "uniFED2"
    if gn in glyf:
        adv = hmtx.metrics[gn][0]
        base = _iso_pathops(glyphset, feh)
        ib = base.bounds
        res = pathops.op(base, _rect(ib[2] - 160, 0, adv + 35, 150), pathops.PathOp.UNION, fix_winding=True)
        res.simplify(fix_winding=True)
        glyf[gn] = _to_glyph(glyf, res)
        hmtx.metrics[gn] = (adv, glyf[gn].xMin)
        count += 1
    return count


# --------------------------------------------------------------------------- #
# General body transplant: keep the PDF isolated body, drop the isolated tail
# (via a clip), reposition, and add baseline connectors. Used for letters whose
# body sits at a consistent height across forms (humps / loop heads).
#   clip_gt_x : keep isolated ink with x > this value (drops a left/low-x tail)
# --------------------------------------------------------------------------- #
# codepoint: (forms, clip_mode, clip_value, dy_body)
#   clip_mode "gtx" keeps isolated ink with x > value (drops a low-x tail);
#   "gty" keeps ink with y > value (used to lift a head off its descender).
#   dy_body shifts the extracted body vertically (meem head down to baseline).
_TRANSPLANTS = {
    0x0633: ({"init": "uniFEB3", "medi": "uniFEB4", "fina": "uniFEB2"}, "gtx", 560, 0),    # seen
    0x0634: ({"init": "uniFEB7", "medi": "uniFEB8", "fina": "uniFEB6"}, "gtx", 560, 0),    # sheen
    0x0642: ({"init": "uniFED7", "medi": "uniFED8", "fina": "uniFED6"}, "gtx", 720, 0),    # qaf
    0x0635: ({"init": "uniFEBB", "medi": "uniFEBC", "fina": "uniFEBA"}, "gtx", 1300, 0),   # sad
    0x0636: ({"init": "uniFEBF", "medi": "uniFEC0", "fina": "uniFEBE"}, "gtx", 1300, 0),   # dad
    0x0644: ({"init": "uniFEDF", "medi": "uniFEE0", "fina": "uniFEDE"}, "gtx", 820, 0),    # lam (stem)
    0x06A9: ({"init": "uniFB90", "medi": "uniFB91", "fina": "uniFB8F"}, "gtx", 1080, 0),   # kaf (corner+diagonal)
    0x06AF: ({"init": "uniFB94", "medi": "uniFB95", "fina": "uniFB93"}, "gtx", 1080, 0),   # gaf
    # meem (م) reverted to base joined forms: the head-drop transplant left the
    # loop floating above the baseline connector and detached the final form.
}


def _bar2(x0, x1):
    return _rect(x0, 0, x1, 150)


def transplant_body(font: TTFont, iso_cp, forms, clip_mode, clip_val, dy_body=0, right_margin=40) -> int:
    glyf = font["glyf"]
    hmtx = font["hmtx"]
    glyphset = font.getGlyphSet()
    cmap = font.getBestCmap()
    if iso_cp not in cmap:
        return 0
    iso_gn = cmap[iso_cp]
    clip = _rect(clip_val, -80, 4000, 1400) if clip_mode == "gtx" else _rect(-200, clip_val, 4000, 1400)
    body = pathops.op(_iso_pathops(glyphset, iso_gn), clip, pathops.PathOp.INTERSECTION, fix_winding=True)
    body.simplify(fix_winding=True)
    if dy_body:
        body = _translate(body, 0, dy_body)
        body.simplify(fix_winding=True)
    bb = body.bounds
    count = 0
    for kind, gn in forms.items():
        if gn not in glyf:
            continue
        adv = hmtx.metrics[gn][0]
        if kind == "fina":
            base = _iso_pathops(glyphset, iso_gn)
            ib = base.bounds
            res = pathops.op(base, _bar2(ib[2] - 220, adv + 35), pathops.PathOp.UNION, fix_winding=True)
        else:
            dx = (adv - right_margin) - bb[2]
            b = _translate(body, dx, 0)
            hx0, hx1 = bb[0] + dx, bb[2] + dx
            res = b
            if kind in ("init", "medi"):
                res = pathops.op(res, _bar2(-35, hx0 + 150), pathops.PathOp.UNION, fix_winding=True)
            if kind == "medi":
                res = pathops.op(res, _bar2(hx1 - 150, adv + 35), pathops.PathOp.UNION, fix_winding=True)
        res.simplify(fix_winding=True)
        glyf[gn] = _to_glyph(glyf, res)
        hmtx.metrics[gn] = (adv, glyf[gn].xMin)
        count += 1
    return count


def fix_body_transplants(font: TTFont) -> int:
    total = 0
    for cp, (forms, mode, val, dy) in _TRANSPLANTS.items():
        total += transplant_body(font, cp, forms, mode, val, dy)
    return total


def apply_weight(font: TTFont, r: float) -> int:
    if r <= 0:
        return 0
    glyphset = font.getGlyphSet()
    glyf = font["glyf"]
    count = 0
    for gname in font.getGlyphOrder():
        g = glyf[gname]
        if g.numberOfContours > 0:  # simple contour glyphs; composites follow
            try:
                new = dilate_glyph(glyphset, gname, r)
            except Exception as exc:  # noqa: BLE001
                print(f"  ! dilate failed {gname}: {exc!r}")
                continue
            if new.numberOfContours > 0:
                new.recalcBounds(glyf)
                glyf[gname] = new
                count += 1
    return count


# --------------------------------------------------------------------------- #
# Naming
# --------------------------------------------------------------------------- #
def set_name(font: TTFont, nid: int, value: str) -> None:
    name = font["name"]
    name.names = [rec for rec in name.names if rec.nameID != nid]
    name.setName(value, nid, 3, 1, 0x0409)  # Windows / Unicode BMP / en-US
    name.setName(value, nid, 1, 0, 0)        # Mac Roman / en


def update_names(font: TTFont, style: Style) -> None:
    ribbi_bold = style.label == "Bold"
    ribbi_regular = not ribbi_bold  # Regular, Medium, SemiBold are RIBBI "Regular"

    # RIBBI split so legacy (GDI) apps can reach every weight, while modern apps
    # group all four under the typographic family via ID16/17 and ID21/22.
    if style.label in ("Regular", "Bold"):
        win_family = FAMILY
    else:
        win_family = f"{FAMILY} {style.label}"
    win_subfamily = "Bold" if ribbi_bold else "Regular"

    # Drop every record we are about to redefine (all platforms), plus any
    # stale extras leaking the source name (e.g. old ID21='Base-Kurdish').
    keep = font["name"].names
    manage = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 18, 19, 20, 21, 22}
    font["name"].names = [rec for rec in keep if rec.nameID not in manage]

    set_name(font, 0, f"Copyright (c) 2026 Base Agency. {FAMILY} font family. All rights reserved.")
    set_name(font, 1, win_family)
    set_name(font, 2, win_subfamily)
    set_name(font, 3, f"BaseAgency:{style.stem}:{VERSION}:2026")
    set_name(font, 4, style.full)
    set_name(font, 5, f"Version {VERSION}")
    set_name(font, 6, style.stem)
    set_name(font, 7, f"{FAMILY} is a trademark of Base Agency.")
    set_name(font, 8, "Base Agency")
    set_name(font, 9, "Base Agency Type Studio")
    set_name(font, 10, "Kurdish (Sorani) type family. Isolated letters and shown symbols follow the supplied letter fixing PDF; connected shaping stays active. Clean stroke-based weight axis.")
    set_name(font, 13, "Proprietary font software owned or controlled by Base Agency. See LICENSE-BASE-AGENCY.txt.")
    set_name(font, 16, FAMILY)          # typographic family
    set_name(font, 17, style.label)     # typographic subfamily
    set_name(font, 18, style.full)      # compatible full (Mac)
    set_name(font, 21, FAMILY)          # WWS family
    set_name(font, 22, style.label)     # WWS subfamily

    os2 = font["OS/2"]
    os2.usWeightClass = style.weight
    os2.usWidthClass = 5
    os2.fsType = 0
    os2.achVendID = "BASE"
    os2.version = max(os2.version, 4)
    # bit5 BOLD, bit6 REGULAR, bit7 USE_TYPO_METRICS, bit8 WWS
    fs = 0x0080 | 0x0100  # USE_TYPO_METRICS + WWS (names are WWS-clean via 21/22)
    if ribbi_bold:
        fs |= 0x0020
    if ribbi_regular:
        fs |= 0x0040
    os2.fsSelection = fs

    head = font["head"]
    head.macStyle = 0x0001 if ribbi_bold else 0x0000
    font["post"].italicAngle = 0.0
    font["post"].isFixedPitch = 0
    if "DSIG" in font:
        del font["DSIG"]
    font.recalcTimestamp = False


# --------------------------------------------------------------------------- #
# Metrics
# --------------------------------------------------------------------------- #
def recalc_head(font: TTFont) -> tuple[int, int]:
    glyf = font["glyf"]
    xn = yn = 10**9
    xx = yy = -(10**9)
    for gname in font.getGlyphOrder():
        g = glyf[gname]
        if g.numberOfContours != 0:
            g.recalcBounds(glyf)
            xn, yn = min(xn, g.xMin), min(yn, g.yMin)
            xx, yy = max(xx, g.xMax), max(yy, g.yMax)
    if xn == 10**9:
        xn = yn = xx = yy = 0
    head = font["head"]
    head.xMin, head.yMin, head.xMax, head.yMax = xn, yn, xx, yy
    return yn, yy


def finalize_vertical(fonts_meta: list[tuple[TTFont, Style]]) -> None:
    """Give every weight identical line metrics; win box covers the boldest."""
    reg = fonts_meta[0][0]
    typo_asc = reg["OS/2"].sTypoAscender
    typo_desc = reg["OS/2"].sTypoDescender
    typo_gap = reg["OS/2"].sTypoLineGap
    hhea_asc = reg["hhea"].ascent
    hhea_desc = reg["hhea"].descent

    win_asc = 0
    win_desc = 0
    for font, _ in fonts_meta:
        yn, yy = recalc_head(font)
        win_asc = max(win_asc, yy + 16)
        win_desc = max(win_desc, -yn + 16)

    for font, _ in fonts_meta:
        os2 = font["OS/2"]
        os2.sTypoAscender = typo_asc
        os2.sTypoDescender = typo_desc
        os2.sTypoLineGap = typo_gap
        os2.usWinAscent = win_asc
        os2.usWinDescent = win_desc
        hhea = font["hhea"]
        hhea.ascent = hhea_asc
        hhea.descent = hhea_desc
        hhea.lineGap = 0


# --------------------------------------------------------------------------- #
# Build
# --------------------------------------------------------------------------- #
def build() -> list[dict]:
    for folder in (FONTS, DOCS, SOURCE, SPECIMEN):
        folder.mkdir(parents=True, exist_ok=True)

    fonts_meta: list[tuple[TTFont, Style]] = []
    reports = []
    for style in STYLES:
        print(f"[{style.label}] loading master")
        font = TTFont(REGULAR_SRC)
        if SMOOTH:
            # Smooth/flowing direction: keep the base font's smooth joined forms;
            # do NOT transplant the geometric PDF bodies into connected text.
            heh = feh = tp = 0
        else:
            heh = fix_heh_forms(font)          # round joined heh BEFORE weighting
            feh = fix_feh_forms(font)          # PDF head into joined feh
            tp = fix_body_transplants(font)    # PDF body into seen/sheen/qaf/sad/dad
        n = apply_weight(font, style.dilate)
        update_names(font, style)
        fonts_meta.append((font, style))
        reports.append({"style": style.label, "weight": style.weight,
                        "dilate_radius": style.dilate, "glyphs_reweighted": n,
                        "smooth": SMOOTH, "heh_forms_rounded": heh, "feh_forms_transplanted": feh})
        print(f"[{style.label}] smooth={SMOOTH}, reweighted {n} glyphs")

    finalize_vertical(fonts_meta)

    for font, style in fonts_meta:
        font.recalcBBoxes = True
        out = FONTS / f"{style.stem}.ttf"
        font.save(out)
        # normalize + web font
        tt = TTFont(out)
        tt.save(out)
        web = TTFont(out)
        web.flavor = "woff2"
        web.save(FONTS / f"{style.stem}.woff2")
        print(f"[{style.label}] wrote {out.name} + woff2")

    return reports


# --------------------------------------------------------------------------- #
# Validation (shaping) via harfbuzz
# --------------------------------------------------------------------------- #
def shape(path: Path, text: str) -> list[str]:
    data = path.read_bytes()
    face = hb.Face(data)
    hb_font = hb.Font(face)
    hb_font.scale = (face.upem, face.upem)
    buf = hb.Buffer()
    buf.add_str(text)
    buf.guess_segment_properties()
    buf.language = "ckb"
    hb.shape(hb_font, buf)
    tt = TTFont(path)
    return [tt.getGlyphName(i.codepoint) for i in buf.glyph_infos]


def validate() -> dict:
    samples = ["کوردستان", "فۆنت", "پەروەردە", "زانکۆ", "ڕوون", "نووسین",
               "ئەکادیمی", "پ چ ژ ڤ گ", "بەڕێوەبردن", "گۆڕانکاری"]
    out = {"family": FAMILY, "version": VERSION, "styles": []}
    for style in STYLES:
        path = FONTS / f"{style.stem}.ttf"
        font = TTFont(path)
        shaping = {s: shape(path, s) for s in samples}
        notdef = [s for s, gs in shaping.items() if ".notdef" in gs]
        if notdef:
            raise RuntimeError({"file": path.name, "notdef": notdef})
        nm = font["name"]
        out["styles"].append({
            "file": path.name,
            "typographic_family": nm.getDebugName(16),
            "typographic_subfamily": nm.getDebugName(17),
            "win_family": nm.getDebugName(1),
            "win_subfamily": nm.getDebugName(2),
            "full_name": nm.getDebugName(4),
            "postscript": nm.getDebugName(6),
            "usWeightClass": font["OS/2"].usWeightClass,
            "glyphs": len(font.getGlyphOrder()),
            "unicode_codepoints": len(font.getBestCmap()),
            "notdef_free": True,
        })
    return out


if __name__ == "__main__":
    reports = build()
    validation = validate()
    validation["build_reports"] = reports
    (DOCS / "validation-report.json").write_text(
        json.dumps(validation, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(validation, ensure_ascii=False, indent=2))
