# BASE Meridion Kurdish design source record

- Family name: **BASE Meridion Kurdish** (typographic family, name ID 16, identical across all four weights).
- Weights: Regular 400, Medium 500, SemiBold 600, Bold 700 (name ID 17 sub-styles).
- Version: 1.010.
- Kurdish design target: `letter fixing.pdf`, supplied by the user (Adobe Illustrator artwork).
- Isolated Kurdish letters and the shown symbols (including `-` and `_`) follow the PDF vector design.
- **Smooth/flowing joined text.** Connected word forms use the smooth, elegant base shapes so running
  Kurdish reads with a soft naskh flow (matching the reference the user supplied), rather than the
  geometric PDF outlines. Single/isolated letters still show the PDF design.
- Latin A-Z and a-z intentionally render as period dots per the user's request.

## What changed
- **Naming fixed (1.003).** The visible/typographic family is now exactly `BASE Meridion Kurdish`. Regular /
  Medium / SemiBold / Bold are sub-styles of that one family (typographic name IDs 16/17 and WWS
  IDs 21/22), with a valid RIBBI split on name IDs 1/2 so every weight is reachable in legacy apps
  too. The old leftover `Base-Kurdish` WWS name was removed.
- **Weight axis rebuilt cleanly (1.003).** Medium, SemiBold and Bold are regenerated from the
  Regular master with a stroke-outset method (skia-pathops union), replacing the previous faux-bold
  that produced lumpy, self-intersecting outlines bloated to ~9x the point count. Bold outlines are
  now smooth, counters stay open, and the four weights share identical letter heights and metrics.
- **Smooth/flowing direction (1.010).** Earlier builds (1.004-1.009) transplanted the geometric PDF
  outlines into the joined start/middle/end forms so words matched the PDF exactly. The user then chose
  the smooth, elegant reference style instead, so the joined forms now keep the base font's soft naskh
  shapes and the geometric transplants are switched off (SMOOTH=True in the build). Isolated letters
  still carry the PDF design; connected text flows smoothly. The transplant code is retained and can be
  re-enabled (SMOOTH=False) if the geometric direction is ever wanted again.
