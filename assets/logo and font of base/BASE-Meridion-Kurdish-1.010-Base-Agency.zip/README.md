# BASE Meridion Kurdish 1.010

One family, four weights:

- `fonts/BASEMeridionKurdish-Regular.ttf` (400)
- `fonts/BASEMeridionKurdish-Medium.ttf` (500)
- `fonts/BASEMeridionKurdish-SemiBold.ttf` (600)
- `fonts/BASEMeridionKurdish-Bold.ttf` (700)
- matching `.woff2` web fonts

The typographic family name is **BASE Meridion Kurdish** for every file, so modern design apps
(Adobe CC, Figma, Canva, current Office, macOS) show a single family named
`BASE Meridion Kurdish` with Regular / Medium / SemiBold / Bold as selectable styles.

Isolated Kurdish letters and the shown symbols follow the supplied `letter fixing.pdf`.
Connected Kurdish shaping stays active. Latin A-Z / a-z render as period dots by design.

Copyright (c) 2026 Base Agency. All rights reserved.
